import pygame
import time
import math

WIDTH = 900
HEIGHT = 500
FPS = 60
WHITE = (255, 255, 255)
button_pressed = 0
ET1shield_unsized = pygame.image.load("imgs\car.png")
ET1shield_resized = pygame.transform.rotate(pygame.transform.scale(ET1shield_unsized, (40, 60)), 0)
BORDER = pygame.Rect(0, 0, 900, 500)
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("ET1 Shield Simulation")

clock = pygame.time.Clock()
run = True


def blit_rotate_center(win, image, top_left, angle):
    rotated_image = pygame.transform.rotate(image, angle)
    new_rect = rotated_image.get_rect(center=image.get_rect(topleft=top_left).center)
    win.blit(rotated_image, new_rect.topleft)


class AbstractCar:
    def __init__(self, max_vel, rotation_vel):
        self.img = self.IMG
        self.max_vel = max_vel
        self.vel = 0
        self.rotation_vel = rotation_vel
        self.angle = 0
        self.x, self.y = self.START_POS
        self.acceleration = 0.1

    def coordinate(self):

        print(f'x: {self.x}, y: {self.y}')

    def rotate(self, left=False, right=False):
        if left:
            self.angle += self.rotation_vel
        elif right:
            self.angle -= self.rotation_vel

    def draw(self, win):
        blit_rotate_center(win, self.img, (self.x, self.y), self.angle)

    def move_forward(self):
        self.vel = min(self.vel + self.acceleration, self.max_vel)
        self.move()

    def move_backward(self):
        self.vel = max(self.vel - self.acceleration, -self.max_vel / 2)
        radians = math.radians(self.angle)
        vertical = math.cos(radians) * self.vel
        horizontal = math.sin(radians) * self.vel
        self.y -= vertical
        self.x -= horizontal

    def move(self):
        radians = math.radians(self.angle)
        vertical = math.cos(radians) * self.vel
        horizontal = math.sin(radians) * self.vel
        if 6 < self.x < 847 and 6 < self.y < 447:
            self.y -= vertical
            self.x -= horizontal

    def reduce_speed(self):
        self.vel = max(self.vel - self.acceleration / 2, 0)
        self.move()


class ET1Shieldcar(AbstractCar):
    IMG = ET1shield_resized
    START_POS = (180, 200)


def draw(ET1Shield):
    WIN.fill(WHITE)
    ET1Shield.draw(WIN)
    pygame.display.update()


ET1Shield = ET1Shieldcar(4, 4)

while run:
    clock.tick(FPS)
    draw(ET1Shield)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            break
    ET1Shield.coordinate()
    keys = pygame.key.get_pressed()
    moved = False

    if keys[pygame.K_a]:
        ET1Shield.rotate(left=True)
    if keys[pygame.K_d]:
        ET1Shield.rotate(right=True)
    if keys[pygame.K_w]:
        moved = True
        ET1Shield.move_forward()
    if keys[pygame.K_s]:
        moved = True
        ET1Shield.move_backward()

    if not moved:
        ET1Shield.reduce_speed()

pygame.quit()
